<?php
    ob_start();
    session_start ();
if(isset($_SESSION["valid"]))
{

    
    //echo $_SESSION["email"];
    
    if ($_SESSION["valid"] == 1)
    include ('header_login.php');
    else if ($_SESSION["valid"] == 2)
    include ('header_admin.php');


}
    // include header.php file
   
   else{ include ('header.php');}
?>

<?php


include ('Template/women.php')

?>


<?php
// include footer.php file
include ('footer.php');
?>