<?php

$conn=mysqli_connect("localhost","root","","shopee");
if(!$conn){
    echo "Connection failed";
}
else{
   //
}


//create data
// if (isset($_POST['create']))
// {
//         echo "<br> successfully connection! <br>";
//         $RegID = $_POST['rid'];
//         $NAME = $_POST['uname'];
//         $EMAIL = $_POST['email'];
//         $PHONE = $_POST['phone'];
//         if (!empty($NAME) && !empty($EMAIL) &&  !empty($RegID)  &&  !empty($PHONE) ) {
//                     $msg = "INSERT INTO `registration`(`Reg_id`, `Name`, `Email`, `Phone`) VALUES ('$RegID','$NAME','$EMAIL','$PHONE')";
//                      if ($conn->query($msg) === TRUE) {
//                         echo "<br>  created successfully! <br>";
//                         echo '<script>alert("created successfully!")</script>';
//                         mysqli_query($conn, $msg);
//                          header("Location: ../../frontend/show.php");
                        
//                     }
//                     else {
                        
//                         echo '<script>alert("Errors!")</script>';
//                         echo "Error: " . $msg . "<br>" . $conn->error;}
//          }

//     }

//delete data 
    //  if(isset($_GET['Remove']))
    // {
    //    $sql_s = "DELETE FROM `registration` WHERE `Reg_id` = '" . $_GET["Remove"] . "'";
       
    //    if (mysqli_query($conn, $sql_s)) {
    //         echo "Record deleted successfully";
    //         header("Location: ../../frontend/show.php");
    //     } 
    // }



// editor data 
if (isset($_GET['edit'])) {
    $update = true;
    $idnew = $_GET["edit"];

    //$data =  "SELECT * FROM inventory WHERE `item_id` = '" . $_GET["edit"] . "'";
    $data = "select item_id, stock from inventory where item_id = '$idnew';";
   
    $result = mysqli_query($conn,$data) or die(mysqli_error($conn));
    print_r($result);
  //  $query = "select email,password, user_id, first_name from user where user.email = '$email' and user.password = '$password';"
    $record = mysqli_query($conn, $data);

    if (mysqli_query($conn, $data)) {
        $n = mysqli_fetch_array($result);
            $id = $n['item_id'];
            $stocki = $n['stock'];
    
    }
    
  }
 
 
  if (isset($_POST['update'])) 
  {
    echo $idnew;
    if(isset($_POST['stock']));
    {
    $new = $_POST['stock'];
    }
 
  $query = "UPDATE inventory SET stock=$new where item_id =";
  $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
  }

// if (isset($_POST['update'])) {
//   if(isset($_POST['stock']));
// {
//   $new = $_POST['stock'];
// }
// $nid = $_POST['item_id'];
// $query = "UPDATE inventory SET stock=$new where item_id = ";
// $result = mysqli_query($conn,$query) or die(mysqli_error($conn));

  
//   }
//   else
//   {

//   }



?>




     
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
       <title> Update - CRUD</title>
      <div class="container px-24 py-24 mx-auto sm:mr-5 p-5 flex float-left">
          <div class="lg:w-2/5 md:w-1/2 bg-white rounded-lg p-8 flex flex-col shadow-lg border border-gray-300">
            <h2 class="text-gray-900 text-lg mb-1 font-medium title-font">Update Stock!</h2>


        <form action="crud.php" method="post">
            

            <div class="relative mb-4">
              <label for="text" class="leading-7 text-sm text-gray-600">Stock</label>
              <input type="text" id="stock" name="stock" value="<?php ?>" class="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out">
            </div>
            
            <button name="update" class="text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded text-lg">Update</button>
          
          </form>
          </div>
      </div>


      <?php 
      //if(isset($_GET['Remove']))
    //{
      //echo $_GET['r']
    //}
    ?>