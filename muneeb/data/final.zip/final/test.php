<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <!-- css -->
       <link rel="stylesheet" href="./stylesheets/header.css">
       <link rel="stylesheet" href="./stylesheets/display-tour.css">
      
        <!-- Java -->
        <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
        <!-- Send email through javascript -->
        <script src="https://smtpjs.com/v3/smtp.js"></script>

</head>
<body>
<nav>
        <div class="logo">
            <img src="./assets/logos/logo_2.png" alt="image">
        </div>

        <!-- set links & active page (setting class to active will highlight the current page) -->
        <div class="nav-links" id="links">
        <a href="./admin-home-page.php" class="active">Home</a>
            <a href="./admin-add.php" class="active">Add</a>
            <a href="./admin-del.php" class="active">Del/update</a>
            

           
            <a href="./search_page.php" class="active">Search</a>
            <div class="searchbar">
                <form action="" method="post">
                <input type="text" placeholder="Search..." name="search">
                <a href="./here.php"><button type="submit"  name ="submit" style="outline: none;border:none;background:#fff;"><i class="fa fa-search" style="color: #232323;"></i></button></a>
                
                </form>
            </div>

        </div>

        <div class="menu">
            <i class="fa fa-bars" id="burger"></i>
        </div>
    </nav>

    <section class="tours">
            <div class="tour-container">
    <?php
    /**'%{$search_item}%' */
            include('config.php');

            

                if(isset($_POST['submit'])){
                    $search_item = $_POST['search'];
        $select_products = mysqli_query($connect, "SELECT * FROM addtrip4 WHERE placename LIKE '%{$search_item}%'") or die('query failed');

                    if(mysqli_num_rows($select_products) > 0){
                        while($rows = mysqli_fetch_array($select_products)){
            ?>
           <div class="tour-box box-1">
           <div class="image">
                <img src="./<?php echo $rows['image']; ?>" width="100%" height="100%">   
                </div>
                <div class="info">
                    <h3>6 Days Trip to <?php echo $rows['placename'];?></h3>
                    <p><i class="fa fa-clock-o"></i> <?php echo $rows['stay'];?> Days</p>
                    <p><i class="fa fa-calendar"></i> Availability : Every Friday Night</p>
                </div>
                <div class="pricing">
                    <div class="price">
                        <p>From</p>
                        <span>PKR</span>
                        <span><?php echo $rows['price'];?></span>
                    </div>
                    <a href="./details.php?tour_id=<?php echo $rows["tour_id"];?>">view detail</a>
                   
               
                </div>
            </div>
            <?php
                        }
                    }
                }
            ?>
    


    </div>
    </section>

</body>
</html>