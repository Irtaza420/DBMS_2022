

<div class="jumbotron text-center">

  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email or the orders tab</strong> for more information.</p>
  <hr>
  <p>
    Having trouble? <a href="contactus.php">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
  </p>
</div>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
