<?php

// require MySQL Connection
require ('database/DBController.php');

// require Product Class
require ('database/Product.php');

// require Cart Class
require ('database/Cart.php');

require ('category.php');


// DBController object
$db = new DBController();

// Product object
$product = new Product($db);
$product_shuffle = $product->getData();

// Cart object
$Cart = new Cart($db );

//print_r($product->getData());

$category = new category($db);
$catman_shuffle = $category->getnew(1);
$catwo_shuffle = $category->getnew(2);
$catkid_shuffle = $category->getnew(3);
