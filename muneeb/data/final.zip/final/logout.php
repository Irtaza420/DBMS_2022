<?php
session_start();
unset($_SESSION["valid"]);
unset($_SESSION["email"]);
unset($_SESSION["id"]);
unset($_SESSION["name"]);
$connect = mysqli_connect("localhost", "root", "") or die(mysqli_error($connect));
mysqli_select_db($connect,"shopee") or die(mysqli_error($connect));  		
mysqli_query($connect, "TRUNCATE TABLE `cart`");
header("Location:index.php");

?>