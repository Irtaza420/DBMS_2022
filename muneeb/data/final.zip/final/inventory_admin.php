

<?php
$conn=mysqli_connect("localhost","root","","shopee");
if(!$conn){
    echo "Connection failed";
}
else{
   //
}
//SQL Query

$query = "SELECT * FROM inventory;";
$result = $conn->query($query);
?>

<?php
  $sql = "CREATE TRIGGER AFTER UPDATE on inventory FOR 
          EACH ROW 
          if new.stock < 5 then SET old.restock = 0;
          end if;
           ";
  $result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

        <head>
            <meta cha$et="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
        
            <title> PHP - CRUD</title>
        </head>
<body style ="margin: auto;
  width: 100%;
  padding: 10px;">

<div class="lg:w-3/6 mx-auto overflow-auto">
<h2 class="text-gray-900 text-lg mb-1 font-medium title-font">Inventory</h2>
              <table class="table-auto w-full text-left whitespace-no-wrap">
                <thead>
                  <tr>
                    <th class="px-4 py-3 title-font tracking-wider font-medium text-gray-900 text-sm bg-gray-100">Product ID</th>
                    <th class="px-4 py-3 title-font tracking-wider font-medium text-gray-900 text-sm bg-gray-100">Stock</th>
                    <th class="px-4 py-3 title-font tracking-wider font-medium text-gray-900 text-sm bg-gray-100">Restock</th>
                    <th class="px-4 py-3 title-font tracking-wider font-medium text-gray-900 text-sm bg-gray-100">Update</th>
                    <th class="px-4 py-3 title-font tracking-wider font-medium text-gray-900 text-sm bg-gray-100">Delete</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                       include 'readData.php';
               ?>
          </div>
        </div>
                   
</body>
</html>