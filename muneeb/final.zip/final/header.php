<?php
ob_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce website</title>

    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- Owl-carousel CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha256-UhQQ4fxEeABh4JrcmAJ1+16id/1dnlOEVCFOxDef9Lw=" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha256-kksNxjDRxd/5+jGurZUJd1sdR2v+ClrCl3svESBaJqw=" crossorigin="anonymous" />

    <!-- font awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=" crossorigin="anonymous" />

    <!-- Custom CSS file -->
    <link rel="stylesheet" href="style.css">


    <script>
        function fill(Value) {
   //Assigning value to "search" div in "search.php" file.
   $('#search-t').val(Value);
   //Hiding "display" div in "search.php" file.
   $('#display').hide();
}
$(document).ready(function() {
   //On pressing a key on "Search box" in "search.php" file. This function will be called.
   $("#search").keyup(function() {
       //Assigning search box value to javascript variable named as "name".
       var name = $('#search').val();
       //Validating, if "name" is empty.
       if (name == "") {
           //Assigning empty value to "display" div in "search.php" file.
           $("#display").html("");
       }
       //If name is not empty.
       else {
           //AJAX is called.
           $.ajax({
               //AJAX type is "Post".
               type: "POST",
               //Data will be sent to "ajax.php".
               url: "ajax.php",
               //Data, that will be sent to "ajax.php".
               data: {
                   //Assigning value of "name" into "search" variable.
                   search: name
               },
               //If result found, this funtion will be called.
               success: function(html) {
                   //Assigning result to "display" div in "search.php" file.
                   $("#display").html(html).show();
               }
           });
       }
   });
});
    </script>
    <?php
    //Getting value of "search" variable from "script.js".
    if (isset($_POST['search-t'])) {
    //Search box value assigning to $Name variable.
   $Name = $_POST['search-t'];
        //Search query.
   $Query = "SELECT item_name FROM product WHERE item_name LIKE '%$Name%' LIMIT 5";
//Query execution
   $ExecQuery = MySQLi_query($con, $Query);
//Creating unordered list to display result.
   echo '<ul>';
   //Fetching result from database.
   while ($Result = MySQLi_fetch_array($ExecQuery)) {
    ?>
   
   <li onclick='fill("<?php echo $Result['item_name']; ?> ")'>
   <a>
       <?php echo $Result['item_name']; ?>
   </li></a>
   <?php
   }
}
?>
</ul>
    <?php
    // require functions.php file
    require ('functions.php');
    ?>
    <style>
        .top-1
        {
            color: black;
            font-size: 11px;
            font-weight: 400;
           
        }
        .top-3
        {
            color:goldenrod;
            padding: 10px;
        }
        .top-3:hover
        {
            background-color: goldenrod;
            color: black;
        }
        /* .logo
        {
            height: 100px;
        } */
        #navbar-1
        {
            background-color:black;
        }
        #navb
        {
            color:goldenrod;
        }
        #nav-text
        {
            color:white;
        }
        #nav-text:hover
        {
            background-color: black;
            color:goldenrod;
        }
        #cart-icon{
            color:black;
        }
        #search-b:hover
        {
            background:goldenrod;
        }
        #search-b:hover
        {
            background:goldenrod;
        }
        #bgcart
        {
            background-color:white;
        }
        #bgcart:hover
        {
            background:goldenrod;
        }
        #bgcart-1
        {
            background-color:goldenrod;
        }
        #bgcart-1:hover
        {
            background:white;
        }
     </style>   

</head>
<body>

<!-- start #header -->
<header id="header">
    <div class="strip d-flex justify-content-between px-4 py-1 bg-light">
        <p class="top-1">Store Timings: 9AM-6PM Mon-Fri | MM Alam Road Gulberg 3 Lahore | 03242414224</p>
        <!-- <div>
        <img src="Aim_icon.jpg" class = "logo">
        </div> -->
        <div class="top-2">           
            <a href="login.php" class="top-3">Login</a>
            <a href="signup.php" class="top-3">SignUp</a>
        </div>
    </div>

    <!-- Primary Navigation -->
    <nav class="navbar navbar-expand-lg" id = "navbar-1">
        <a class="navbar-brand" id = "navb" href="index.php">AIM Clothing Store</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav m-auto font-rubik">
                <li class="nav-item active">
                    <a class="nav-link" id = "nav-text" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id = "nav-text" href="#">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  id = "nav-text" href="contactus.php">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  id = "nav-text" href="#">About</a>
                </li>
            </ul>
            
            <form action="#" class="font-size-14 font-rale">
                <input type="text" id = "search-t" placeholder="Search..." name="search">
                <button type="submit"><i class="fa fa-search" id = "search-b"></i></button>
                <a href="cart.php" class="py-2 rounded-pill" id = "bgcart">
                    <span class="font-size-16 px-2 text-white"><i class="fas fa-shopping-cart" id = "cart-icon"></i></span>
                    <span class="px-3 py-2 rounded-pill text-dark " id = "bgcart-1"><?php echo count($product->getData('cart')); ?></span>
                </a>
            </form>
        </div>
    </nav>
    <!-- !Primary Navigation -->

</header>
<!-- !start #header -->

<!-- start #main-site -->
<main id="main-site">