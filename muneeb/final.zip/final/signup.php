
<?php
$connect = mysqli_connect("localhost", "root", "") or die(mysqli_error($connect));
  mysqli_select_db($connect,"shopee") or die(mysqli_error($connect));
if(isset($_POST['signup']))
{


     $fname = $_POST['fname'];
     $lname = $_POST['lname'];
     $email = $_POST['email'];
     $address = $_POST['address'];
     $phoneno = $_POST['phoneno'];
     $password = $_POST['password'];
     $timestamp = date("Y-m-d H:i:s");
     $query = "Insert into user (first_name,last_name,register_date,email,Address,Phone,password) Values ('$fname','$lname','$timestamp','$email','$address','$phoneno','$password');";
     $result = mysqli_query($connect,$query) or die(mysqli_error($connect));
    

  header("Location: /final/login.php");

}
//   else{
//       echo '<script type="text/JavaScript"> alert("Incorrect Email or Password.");</script>';
//   header("Location: /final/new.php");
//   }

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp Page</title>
    <link rel = "stylesheet" href="signup.css">

    <style>
        #link11
        {
            color:goldenrod;
            margin-left: 300px;
        }
        #link11:hover
        {
            font-size:20px;
        }
        .btn11:hover
        {
            background-color: black;
            color:goldenrod;
        }
     
    </style>
</head>
<body>
<form action = "signup.php" method = "post">
    <div class="box" id ="box11">
        <div class = "form">
            <h2 id = "su">Sign Up</h2>
            
            <div class = "inputbox" required = "required">
                    <input type = "textbox" required = "required" id = "fname" name = "fname" class = "text-input">
                    <span class = "sp1">First name</span>
                    <i></i>
        
                <input type = "textbox" required = "required" id = "lname" name = "lname" class = "text-input" >
                <span class = "sp2">last name</span>
                <i></i>
            </div>
            <div class = "inputbox" required = "required">
                <input type = "email" required = "required" id = "Email" name = "email" class = "text-input">
                <span class = "sp3">Email</span>
                <i></i>
            </div>
            <div class = "inputbox" required = "required">
                <input type = "textbox" required = "required" id = "Address" name = "address" class = "text-input">
                <span class = "sp4">Address</span>
                <i></i>
            </div>
            <div class = "inputbox" required = "required">
                <input type = "textbox" required = "required" id = "PhoneNo" name = "phoneno" class = "text-input">
                <span class = "sp5">Phone No</span>
                <i></i>
            </div>
            <div class = "inputbox" required = "required">
                <input type = "password" required = "required" id = "Password" name = "password" class = "text-input">
                <span class = "sp6">Password</span>
                <i></i>
            </div>
            <div id = "buttons">
                <input type = "submit" class = "btn11" name = "signup" id = "signupg" value = "Sign Up">
                <a id="link11" href="login.php">Log In</a>
            </div>
          
        </div>
    </div>
</form>
</body>
</html>



