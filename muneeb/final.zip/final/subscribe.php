

<?php
$connect = mysqli_connect("localhost", "root", "") or die(mysqli_error($connect));
mysqli_select_db($connect,"shopee") or die(mysqli_error($connect));
if(isset($_POST['sub']))
{
    $email = $_POST['email'];
    $query = "Insert into mail_list (email) values ('$email')";
    $result = mysqli_query($connect,$query) or die(mysqli_error($connect));
    header("Location: /final/index.php");
}
?>

<head>
    <style>
        #icon-1
        {
            height:120px;
        }
        #last
        {
            color:goldenrod;
            background-color: black;
            height: 25px;
        }
        #last-text
        {
            align-items:center;
            justify-content: center;
            font-size: 12px;
        }
        #foot-1
        {
            
        }
        #ft-sub
        {
            display: inline-block;
            padding: 10px 45px;
            background-color: goldenrod;
            border: 1px solid black;
            color: black;
            border-radius: 35px;
            transition: 0.3s;
            text-transform: uppercase;
            margin-top: 35px;
            font-weight: 600;
            width: 100%;
            max-width: 285px;
        }
        #ft-sub:hover
        {
            font-size: 18px;
            color:white;
        }
        #ft-input
        {
            background:white;
            font-size: 14px;
            margin-bottom: 20px;
            text-transform: capitalize;
            line-height: normal;
            width: 100%;
            height: 60px;
            border: none;
            border-radius: 90px;
            outline: none;
            padding: 5px 25px;
            background-color: white;
            margin-top: 15px;
            text-align: left;
        }
        #ft1-con
        {
            width: 100%;
            /* margin-left: 100px; */
        }
        #ft-sec
        {
            width: 100%;
            padding-right: 15px; 
            padding-left:15px;
            margin-left:auto;
            margin-right: auto;
        }
        #ft-r
        {
            display: flex;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;

        }
        footer
        {
            background: white;
            padding: 90px 0 70px;
        }
        .logo_footer
        {
            margin-bottom: 30px;
        }

        .widget_menu{
            float: left;
            width: 100%;
        }
        .widget_menu ul{
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .widget_menu li{
            float: left;
            width: 100%;
        }
        .widget_menu a{
            font-size: 15px;
            color:black;
            margin-bottom: 0;
            margin-top: 5px;
            float: left;
            width: 100%;
        }
        .widget_menu a:hover{
            font-size: 17px;
            color:goldenrod;
           
        }
        .widget_menu h3{
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.2px;
            margin-bottom: 25px;
        }
        .feild{display:flex;}
        div.form_sub .field input[type = "email"]
        {
            padding: 10px 110px 10px 15px;
            border-radius:0;
            border:solid black 1px;
            font-size: 14px;
            position: relative;
            box-shadow: none;
            width:100%;
            height:48px;
        }
        .form_sub input[type= "email"] + input[type = "submit"]
        {
            position: relative;
            right: 0;
            background: black;
            color: goldenrod;
            border:none;
            top:0px;
            font-size: 14px;
            height: 48px;
            font-weight:600;
            padding: 0 15px;
        }
        #s-ft:hover
        {
            background-color: goldenrod;
            color:white;
        }
        #pp{
            color: black;
            font-weight: 500px;
        }
    </style>
</head>
</br></br></br>
    <section class="subscribe_section">
         <div class="container-fuild" id = "ft1-con" >
            <div class="box">
               <div class="row">
                  <div class="col-md-6 offset-md-3">
                     <div class="subscribe_form ">
                        <div class="heading_container heading_center">
                           <h3>Subscribe To Get Discount Offers</h3>
                        </div>
                        <p>Enter Your Email down Below!</p>
                        <form action="subscribe.php" method ="post">
                           <input type="text" placeholder="Enter your email" id = "ft-input" name ="email">
                           <button type = "submit" id = "ft-sub" name = "sub">
                           subscribe
                           </button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>