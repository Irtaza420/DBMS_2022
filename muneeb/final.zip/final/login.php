
<?php
session_start();
    

      $connect = mysqli_connect("localhost", "root", "") or die(mysqli_error($connect));
    	mysqli_select_db($connect,"shopee") or die(mysqli_error($connect));
     if(isset($_POST['login']))
    {

   		$password = $_POST['password'];
   		$email = $_POST['email'];
   		$query = "select email,password from user where user.email = '$email' and user.password = '$password';";
	 
   		$result = mysqli_query($connect,$query) or die(mysqli_error($connect));

		if (mysqli_num_rows($result) == 0) { 
		echo '<script type="text/JavaScript"> alert("Incorrect Email or Password.");</script>';
		header("Location: /final/login.php");
		} 
        else { 
            $_SESSION["valid"]="1";
			$_SESSION["email"]=$email;

           // echo $_SESSION["email"];
   		header("Location: /final/index.php");
		}  
	
    }
	
	// if(isset($_POST['createg']))
    // {
   	// 	header("Location: /lab6demo/gmail_signUp_page.php");}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
<style>
    @import url('http://fonts.googleapis.com/css2?family=Poppins:wght@200;400;500;600;700;800;900&display=swap');

*
{
    margin: 0;
    padding: 0;
    font-family: 'Poppins' ,sans-serif;
    box-sizing: border-box;
}
body
{
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: black;
    
}

.box {
    width: 380px;
    height: 420px;
    border: 2px;
    box-shadow: 16px 14px 20px #0000008c;
    border-radius: 20px;
    position: relative;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
   
}
.box::before{
    content: "";
    background-image: conic-gradient(
        goldenrod 100deg,
        transparent 120deg
    );
    width: 150%;
    height: 150%;
    position: absolute;
    animation: rotate 2s linear infinite;
}
.box::after{
    content: "Animation";
    width: 190px;
    height: 190px;
    background: #101010;
    position: absolute;
    border-radius: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    color: goldenrod;
    font-size: larger;
    letter-spacing: 5px;
    box-shadow: inset 20px 20px 20px #0000008c;
}
@keyframes rotate {
    0%{
        transform: rotate(0deg);
    }
    100%{
        transform: rotate(360deg);
    }
}

.form
{
    position: absolute;
    border-radius: 8px;
    background: #28292d;
    z-index: 10;
    padding : 50px 40px;
    display:flex;
    flex-direction: column;
}
.form h2
{
    color: goldenrod;
    font-weight: 500;
    text-align: center;
    letter-spacing: 0.1rem;
}
.inputbox
{
    position: relative;
    width: 300px;
    margin-top: 35px;
}

.inputbox input
{
    position: relative;
    width: 100%;
    padding: 20px 10px 10px;
    background: transparent;
    border: none;
    outline: none;
    color: #23242a;
    font-size: 1em;
    letter-spacing: 0.05em;
    z-index: 10;
}

.inputbox span
{
    position: absolute;
    left: 0;
    padding: 20px 10px 10px;
    font-size: 1em;
    color: #8f8f8f;
    pointer-events: none;
    letter-spacing: 0.05em;
    transition: 0.5s;
    
}
.inputbox input:valid ~span,
.inputbox input:focus ~span
{
    color : goldenrod;
    transform: translateX(0px) translateY(-34px);
    font-size: 0.75em;
}

.inputbox i
{
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background: #DAA520;
    border-radius: 4px;
    transition: 0.5s;
    pointer-events: none;
}

.inputbox input:valid ~i,
.inputbox input:focus ~i
{
    height: 44px;
}

.link
{
    display:flex;
    justify-content: space-between;
}
.link a
{
    margin: 10px 0;
    font-size: 0.75em;
    color: #8f8f8f;
    text-decoration: none;
}
.link a:hover,
.link a:nth-child(2)
{
    color:#DAA520;
}

input[type = "submit"]
{
    border: none;
    outline: none;
    background: #DAA520;
    padding: 11px 25px;
    width: 100px;
    margin-top: 10px;
    border-radius: 4px;
    font-weight: 600;
    cursor: pointer;
}

input[type = "submit"]:active
{
    opacity: 0.8;
}
#ssup:hover
{
    font-size: 14px;
}
#lo:hover
{
    background-color: black;
    color: goldenrod;
}
</style>



</head>
<body>
<form action = "login.php" method = "post">
    <div class = "box">
        <div class = "form">
            <h2>Sign in</h2>
            <div class = "inputbox">
                <input type = "text" required = "required" id = "username" name = "email" >
                <span>Email</span>
                <i></i>
            </div>
            <div class = "inputbox">
                <input type = "password" required = "required"id = "password" name = "password" >
                <span>Password</span>
                <i></i>
            </div>
            <div class ="link">
                <a href = "signup.php">Forget Password?</a>
                <a href = "signup.php" id = "ssup">Sign Up</a>
            </div>
            <input type ="submit" value ="Login" name = "login" id = "lo">
        </div>
    </div>
</form>
</body>
</html>


