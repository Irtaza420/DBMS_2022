<!-- Owl-carousel -->
<head>
    <style>
        #bt-con
        {
            display:flex;
            align-content:center;
            justify-content:center;
        }
        #sh-btn
        {
            cursor:pointer;
            font-size: 1.2rem;
            height: 2.5rem;
            border: 3px solid black;
            margin-left: -730px;
            margin-top: -300px;
            color: goldenrod;
            background-color:black;
            height: 50px;
        }
        #sh-btn:hover
        {
            color: white;
            background-color:transparent;
        }
        #sh-btn:active
        {
            transform:translate(0,0.3rem);
            box-shadow: 0 0.1rem;
        }
        #sh-btn3
        {
            border: 3px solid black;
            color: goldenrod;
            background-color:black;
            height: 50px;
        }
        #sh-btn3:hover
        {
            color: white;
            background-color:transparent;

        }
    </style>
</head>
<section id="banner-area">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="./assets/Banner1.png" alt="Banner1">
            <div class = "carousel-caption">
                <a href= "#" target = "_blank"><button type = "button" class = "btn btn-default" id = "sh-btn">Shop Now</button></a>
            </div>
        </div>
        <div class="item">
            <img src="./assets/Banner2.png" alt="Banner2">
            <div class = "carousel-caption">
                <a href= "#" target = "_blank"><button type = "button" class = "btn btn-default" id = "sh-btn">Shop Now</button></a>
            </div>
           
        </div>
        <div class="item">
            <img src="./assets/Banner3.png" alt="Banner3">
            <div class = "carousel-caption" id = "bt-con">
                <a href= "#" target = "_blank"><button type = "button" class = "btn btn-default" id = "sh-btn3">Shop Now</button></a>
            </div>
        </div>
    </div>
   
</section>
<!-- !Owl-carousel -->
